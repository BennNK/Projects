Nothing special..
But I do apologize for submitting my hw late. Please see my email for details.