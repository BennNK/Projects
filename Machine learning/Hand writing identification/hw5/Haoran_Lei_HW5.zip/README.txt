This is the work of Haoran Lei
Using python 3.8.3
